create procedure getabs(val bigint, returnval bigint)
    language plpgsql
as
$$
begin
        SELECT abs(val) INTO returnVal;
    end;
$$;

alter procedure getabs(bigint, bigint) owner to username;

