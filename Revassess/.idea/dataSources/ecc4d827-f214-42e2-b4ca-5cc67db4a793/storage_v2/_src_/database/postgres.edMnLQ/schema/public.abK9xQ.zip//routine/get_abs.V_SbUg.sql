create function get_abs(val bigint) returns bigint
    language plpgsql
as
$$
begin
        RETURN ABS(val) ;
    end;
$$;

alter function get_abs(bigint) owner to username;

